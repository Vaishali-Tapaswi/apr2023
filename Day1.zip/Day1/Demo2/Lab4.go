package main
import "fmt"

func main(){
	primes := [6]int{2, 3, 5, 7, 11, 13}
	fmt.Println(primes ,", Cap= " , cap(primes), ", Len = " , len(primes) )
	sl1 := primes[1:4]
	fmt.Println(sl1 ,", Cap= " , cap(sl1), ", Len = " , len(sl1) )
	sl1[0] = 111
	fmt.Println(primes ,", Cap= " , cap(primes), ", Len = " , len(primes) )
	fmt.Println(sl1 ,", Cap= " , cap(sl1), ", Len = " , len(sl1) )
	sl1 = append(sl1,55)
	//sl1[4] = 5500 -> Runtime - Panic
	fmt.Println("Primes:", primes ,", Cap= " , cap(primes), ", Len = " , len(primes) )
	fmt.Println("Sl1 :",sl1 ,", Cap= " , cap(sl1), ", Len = " , len(sl1) )
	sl1 = append(sl1,66)
	fmt.Println("Primes:", primes ,", Cap= " , cap(primes), ", Len = " , len(primes) )
	fmt.Println("Sl1 :",sl1 ,", Cap= " , cap(sl1), ", Len = " , len(sl1) )
	sl1 = append(sl1,77)
	fmt.Println("Primes:", primes ,", Cap= " , cap(primes), ", Len = " , len(primes) )
	fmt.Println("Sl1 :",sl1 ,", Cap= " , cap(sl1), ", Len = " , len(sl1) )
	
}