package main 
type Emp struct{
	Empno int
	Ename string
	Salary int
}