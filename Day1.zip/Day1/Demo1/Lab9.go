//Accept a number from user and print fibonacci series till that number
package main
import(
	"fmt"
	
)
func main(){
//	name:="aaa"
	count :=0
	fmt.Println("Enter Number")
	fmt.Scan(&count)
	fmt.Println("Print till  ", count)

	switch count {
	case 0:
	case 1:
		fmt.Println("0")
	case 2:
		fmt.Println("0,1")
	default:
		n1, n2 := 0, 1
		fmt.Print("0,1")
		for n1+n2 < count {
			n3 := n1+ n2
			n1 = n2
			n2 = n3
			fmt.Print("," , n3)
		}
	}
}