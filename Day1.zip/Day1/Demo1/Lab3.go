package main
import(
	"fmt"
)
func main(){
	str1,str2:="One","Two"
	fmt.Println("Str1 = " , str1 , ", Str2 = " , str2)
	str1,str2=swap(str1,str2)
	fmt.Println("Str1 = " , str1 , ", Str2 = " , str2)
}
func swap(str1, str2 string) (string, string){
	return str2, str1
}