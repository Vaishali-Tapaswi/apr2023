package main
import(
	"fmt"
	
)
func main(){
	fmt.Println("starting main")
	for i:=1;i<5;i++{
		defer	fmt.Println("Hello " , i)
	}
	fmt.Println("closing main")
}