package main

import (
	"github.com/aws/aws-sdk-go/aws"
	"github.com/aws/aws-sdk-go/aws/session"
	"github.com/aws/aws-sdk-go/service/lambda"
	"encoding/json"
	"fmt"
	"os"
)

type helloRequest struct {
	Name     string `json:"name"`
}
type helloResponseHeaders struct {
	ContentType string `json:"Content-Type"`
}

func main() {
	// Create Lambda service client
	sess := session.Must(session.NewSessionWithOptions(session.Options{
		SharedConfigState: session.SharedConfigEnable,
	}))

	client := lambda.New(sess, &aws.Config{
			  Region: aws.String("us-east-1")})

	request := helloRequest{"fromLambdaClient"}

	payload, err := json.Marshal(request)
	if err != nil {
		fmt.Println("Error marshalling MyGetItemsFunction request")
		os.Exit(0)
	}

	result, err := client.Invoke(
			  &lambda.InvokeInput{FunctionName: aws.String("helloJeelani"),
			   Payload: payload})
	if err != nil {
		   fmt.Println("Error calling helloJeelani FUnction", err)
		os.Exit(0)
	}
	   fmt.Println("Result " , result)
	   fmt.Println("Error ", err)
	   fmt.Println("\n\nPayload " , string(result.Payload))

}