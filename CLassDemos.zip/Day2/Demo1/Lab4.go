package main
import "fmt"
type Modify interface{
	Add(int)
}
type Twodpoint struct{
	X int
	Y int
}
type Threedpoint struct{
	X int
	Y int
	Z int
}
func (p *Twodpoint)	Add(delta int){
	p.X += delta
	p.Y += delta
}
func (p *Threedpoint)	Add(delta int){
	p.X += delta
	p.Y += delta
	p.Z += delta
}


func main(){
//     Ask user choise of 2D/3D and using interface invoke add(5) 
	fmt.Println("Enter 2/3")
	ch := 0
	fmt.Scanln(&ch)
	var modify Modify
	if ch == 2{
		modify = &Twodpoint{10,44}
	}else if ch == 3{
		modify = &Threedpoint{10,55,70}
	}else{
		fmt.Println("Wrong Input")
	}
	fmt.Println(modify)
	modify.Add(1)
	fmt.Println(modify)

}
  