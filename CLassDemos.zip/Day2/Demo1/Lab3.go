package main
import "fmt"
type Myinterface interface{
	Shift() 
}
type Point struct{
	X int
	Y int
}
func (pt Point) Shift(){
	fmt.Println("Shift invoked ..")
}
func main() {
	p1 := Point{10,10}
	fmt.Println(p1)
	var myinterface Myinterface
	myinterface = p1
	myinterface.Shift()
}