package main
import (
	"fmt"
	"github.com/magiconair/properties"
)

func main() {
	
	p := properties.MustLoadFile("simple.properties", properties.UTF8)
	port, ok := p.Get("port")
	if ok 	{ 
		fmt.Println(port)
	}
}