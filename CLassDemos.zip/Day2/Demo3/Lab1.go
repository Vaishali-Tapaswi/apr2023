package main
import (
	"net/http"
 	"fmt"
	"io"
	
)

func main(){
	resp, _ := http.Get("https://reqres.in/api/users/2")
	defer resp.Body.Close()
	body, _ := io.ReadAll(resp.Body)
	fmt.Println(string(body))

}