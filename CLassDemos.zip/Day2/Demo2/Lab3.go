package main
import (
	"time"
 	"fmt"
)
func main(){

	c := make(chan string)
	go sender(c)
	go receiver(c)
	time.Sleep(10 * time.Second)
	fmt.Println("main Over")

}
func receiver(ch chan string){
	fmt.Println("Waiting for channel input")
	s := <-ch
	fmt.Println("Got ", s, " on channel ")
	
}
func sender(ch chan string){
	fmt.Println("Sending str1 to channel")
	ch <- "str1"
	fmt.Println("Finished sending str1 to channel")
/*	fmt.Println("Sending str2 to channel")
	ch <- "str2"
	fmt.Println("Finished sending str2 to channel")*/
}