package main
import (
	"time"
 	"fmt"
	"math/rand"
//	"strconv"
	"sync"
)
var mutex sync.Mutex
type Bank struct{
	Balance int
}
func main(){
	bank := Bank{}
	go Deposit(&bank)
	go Widraw(&bank)
	time.Sleep(40 * time.Second)
	fmt.Println("main Over" , bank.Balance)

}
func Deposit(bank *Bank){
	for i:=1; i<=100;i++{
		mutex.Lock()
		bal := bank.Balance
		time.Sleep(time.Duration(rand.Int()%100) * time.Millisecond)
		bal++
		bank.Balance = bal
		mutex.Unlock()
		fmt.Println("In Deposit - Current Balance =" , bank.Balance)
	}
}
func Widraw(bank *Bank){
	for i:=1; i<=100;i++{
		mutex.Lock()
		bal := bank.Balance
		time.Sleep(time.Duration(rand.Int()%100) * time.Millisecond)
		bal--
		bank.Balance = bal
		mutex.Unlock()
		fmt.Println("In Widraw - Current Balance =" , bank.Balance)
	}
}