package main
import (
	"time"
 	"fmt"
	"strconv"
)
func main(){
	c := make(chan string,10)
	go sender(c)
	go receiver(c)
	time.Sleep(20 * time.Second)
	fmt.Println("main Over")

}
func receiver(ch chan string){
	fmt.Println("Waiting for channel input")
//	for _, _ = range <-ch{
	for {
		s := <- ch
		fmt.Println(".......Got ", s, " on channel ")
	 }
   
}
func sender(ch chan string){
	for i:=0;i<10;i++{
		fmt.Println("Sending str",i," to channel")
		ch <- "str"+strconv.Itoa(i)
		fmt.Println("Finished sending str",i," to channel")
	}
}