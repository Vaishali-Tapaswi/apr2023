package main
import (
	"time"
 	"fmt"
)
func main(){
	fmt.Println("start of main")
	go helper("-")
	go helper("*")
	
	fmt.Println("end of main")
	time.Sleep(20 * time.Second)
}
func helper(str string){
	for i:=1;i<10;i++{
		fmt.Print(str," ")
		time.Sleep(1 * time.Second)
	}
}