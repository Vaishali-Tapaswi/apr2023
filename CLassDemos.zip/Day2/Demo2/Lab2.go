package main
import (
	"time"
	"math/rand"
 	"fmt"
)
var finalcity = ""
func main(){
	fmt.Println("start of main")
	go helper("Delhi")
	go helper("Hyd")
	go helper("Blr")
	
	fmt.Println("end of main")
	time.Sleep(20 * time.Second)
	fmt.Println("main - Final Destination Choosen is " , finalcity)
}
func helper(str string){
	for i:=1;i<10;i++{
		fmt.Print(str," ",i)
		time.Sleep(time.Duration(rand.Int()%100) * time.Millisecond)
	}
	if finalcity==""{
		finalcity = str
		fmt.Println("\n\nFinal CIty is  " , finalcity)
	}

}