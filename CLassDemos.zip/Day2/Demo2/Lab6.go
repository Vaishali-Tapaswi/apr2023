package main
import (
	"time"
 	"fmt"
	"math/rand"
//	"strconv"
	"sync"
)
var mutex sync.Mutex
type Bank struct{
	Balance int
}
func main(){
		var wg sync.WaitGroup
		wg.Add(4)
		bank := Bank{}
		go func() {
			Deposit(&bank)
			wg.Done()
		}()
		go func() {
			Widraw(&bank)
			wg.Done()
		}()
		fmt.Println("before wait...")
		wg.Wait()
		fmt.Println("in main after deposit and widraw ")
	}
func Deposit(bank *Bank){
	for i:=1; i<=10;i++{
		mutex.Lock()
		bal := bank.Balance
		time.Sleep(time.Duration(rand.Int()%100) * time.Millisecond)
		bal++
		bank.Balance = bal
		mutex.Unlock()
		fmt.Println("In Deposit - Current Balance =" , bank.Balance)
	}
}
func Widraw(bank *Bank){
	for i:=1; i<=10;i++{
		mutex.Lock()
		bal := bank.Balance
		time.Sleep(time.Duration(rand.Int()%100) * time.Millisecond)
		bal--
		bank.Balance = bal
		mutex.Unlock()
		fmt.Println("In Widraw - Current Balance =" , bank.Balance)
	}
}