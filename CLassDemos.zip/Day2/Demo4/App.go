package main
import (
	"database/sql"
	_ "github.com/go-sql-driver/mysql"
	"fmt"
)
func main(){
	db, err := sql.Open("mysql", "admin:MyPassword@tcp(mydb.cxmg6nnxkwnv.us-east-1.rds.amazonaws.com:3306)/mydb")
	defer db.Close()	
	fmt.Println("db",db)
	fmt.Println("err",err)
	//func (db *DB) Exec(query string, args ...any) (Result, error)
	res, err := db.Exec("insert into emp values(0,'AA',111)");
	fmt.Println("res",res)
	fmt.Println("err",err)
	rows, err := db.Query("select * from emp")
	defer rows.Close()
	for rows.Next() {
		var (
			empno   int64
			ename string
			salary int64
		)
		rows.Scan(&empno, &ename, &salary); 
		fmt.Println(empno, " , " ,ename,",", salary)
	}

}