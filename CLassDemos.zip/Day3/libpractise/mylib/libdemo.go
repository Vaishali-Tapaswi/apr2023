package mylib

import "fmt"


func Hello(name string) string {
  	fmt.Println("Greetings - Hello invoked ", name)
    message := "Hi" + name + " Welcome!"
    return message
}