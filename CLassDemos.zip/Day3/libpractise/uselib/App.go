package main

import (
    "fmt"
	"demo/mylib"
)

func main() {
    // Get a greeting message and print it.
  //  message := greetings.Hello("Gladys")
   // fmt.Println(message)
   fmt.Println("in main.main of uselib")
   message := mylib.Hello("Siemens")
   fmt.Println("Output = " , message)
}