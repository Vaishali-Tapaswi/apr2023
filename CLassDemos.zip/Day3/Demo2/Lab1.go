package main

import (
	"encoding/json"
	"fmt"
	"io"
	"log"
	"net/http"
)

var empmgr = EmpMgr{}

func main() {
	
	empHandler := func(w http.ResponseWriter, req *http.Request) {
		switch req.Method {
		case "GET":
			barr, _ := json.Marshal(empmgr.list())
			fmt.Fprintln(w, string(barr))
		case "POST":
			fmt.Fprintln(w, "POST Request invoked ")
			emp := Emp{}
			decoder := json.NewDecoder(req.Body)
			decoder.Decode(&emp)
			fmt.Println(emp)
			empmgr.add(emp)
		}

	}
	http.HandleFunc("/", func(w http.ResponseWriter, req *http.Request) {
		io.WriteString(w, "<h1><a href='emps'>List Employees</a></h1>")
	})
	http.HandleFunc("/emps", empHandler)

	fmt.Println("Starting Server on 8080")
	log.Fatal(http.ListenAndServe(":8080", nil))
}
