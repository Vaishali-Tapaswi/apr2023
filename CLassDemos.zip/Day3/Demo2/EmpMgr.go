package main

import (
	"fmt"
)

type Emp struct {
	Empno  int    `json:"empno"`
	Ename  string `json:"empname"`
	Salary int    `json:"salary"`
}
type EmpMgr struct {
	emparr []Emp
}

func (empmgr *EmpMgr) add(emp Emp) {
	fmt.Println("EmpMgrAdd ", emp)
	empmgr.emparr = append(empmgr.emparr, emp)
}

func (empmgr EmpMgr) list() []Emp {
	fmt.Println("EmpMgrAdd ", len(empmgr.emparr))
	return empmgr.emparr
}

/*
func main(){
	emp := Emp{1, "AA", 111}
	empmgr := EmpMgr{}
	empmgr.add(emp)
	empmgr.add(Emp{2, "BB", 222})
	for i, v:= range empmgr.list(){
		fmt.Println(i, "  -  ", v)
	}
}
*/
