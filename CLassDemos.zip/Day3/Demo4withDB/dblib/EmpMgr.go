package dblib

import (
	"fmt"
	"database/sql"
    _ "github.com/go-sql-driver/mysql"
	"strconv"
)
type Emp struct {
	Empno  int    `json:"empno"`
	Ename  string `json:"empname"`
	Salary int    `json:"salary"`
}
type EmpMgr struct {
	
}
func (empmgr *EmpMgr) connect() *sql.DB {
	db, err := sql.Open("mysql","admin:MyPassword@tcp(mydb.cxmg6nnxkwnv.us-east-1.rds.amazonaws.com:3306)/mydb")
	if err != nil {
		panic(err)
	}
	return db
}

func (empmgr *EmpMgr) Add(emp Emp) {
	fmt.Println("EmpMgrAdd ", emp)
	db :=empmgr.connect()
	defer db.Close()
	sql1 :=  "insert into emp values (" + strconv.Itoa(emp.Empno) +
	 ",'" + emp.Ename + "','"+strconv.Itoa(emp.Salary)+"')"
	fmt.Println("sql", sql1)
	result, err := db.Exec(sql1)
	if err != nil {
		fmt.Println("Error " , err)
	}
	result.RowsAffected()
}

func (empmgr EmpMgr) List() []Emp {
	db := empmgr.connect()
	defer db.Close()
	res, err := db.Query("SELECT * FROM emp")
	defer res.Close()
	if err != nil {
   		panic(err)
	}
	empslice:=make([]Emp,0)
	for res.Next() {
		emp := Emp{}
		res.Scan(&emp.Empno, &emp.Ename, &emp.Salary)
		empslice= append(empslice,emp)	
	}
	return empslice
}

/*
func main(){
	emp := Emp{1, "AA", 111}
	empmgr := EmpMgr{}
	empmgr.add(emp)
	empmgr.add(Emp{2, "BB", 222})
	for i, v:= range empmgr.list(){
		fmt.Println(i, "  -  ", v)
	}
}
*/
