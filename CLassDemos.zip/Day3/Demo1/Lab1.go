package main
import (
	"fmt"
)
func add(x, y int ) int {
	return x+y
}
func divide(x, y int ) int {
	return x/y
}
func main(){
	fmt.Println("add with 10 and 20", add(10,20))
	fmt.Println("divide with 100 and 20", divide(100,20))
}