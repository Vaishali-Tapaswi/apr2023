package main

import "testing"
func BenchmarkAdd(b *testing.B) {
    for i := 0; i < b.N; i++ {
       add(10,i)
    }
}

func TestAdd(t *testing.T) {
    got := add(10,30)
    if got != 40 {
        t.Errorf("add(10,30) = %d; want 40", got)
    }
}

func TestDivide1(t *testing.T) {
    got := divide(100,50)
    if got != 2 {
        t.Errorf("add(10,30) = %d; want 2", got)
    }
}
// divide with 0 should panic, so recover and check if error is not nil -> pass

func TestDivide2(t *testing.T) {
    defer func(){
		r:=recover()
		if r == nil{
			t.Errorf("divide(100,0) = should panic")
		}
	}()
	divide(100,0)
}