package main

import (
	"encoding/json"
	"fmt"
)
type Emp struct {
	Empno   int    `json:"empno"`
	Ename string `json:"empname"`
	Salary  int    `json:"salary"`
}

func main() {
	emp  :=Emp{1,"Vaishali",111}
	b, err := json.Marshal(emp)
	if err != nil {
		fmt.Println("error:", err)
	}
	fmt.Println(string(b))
	fmt.Println(emp)

	
}
