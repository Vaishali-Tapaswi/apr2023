package main
import(
	"fmt"
	
)
func main(){
//	name:="aaa"
	age :=10
	fmt.Println("Current Age =", age)
	fmt.Println("Enter your Age")
	cnt, err:=fmt.Scan(&age)
	fmt.Println("cnt = ", cnt , "err = ", err)
	fmt.Println("Current Age =", age)

}