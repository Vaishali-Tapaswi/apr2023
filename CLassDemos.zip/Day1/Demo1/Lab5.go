package main
import(
	"fmt"
	"os"
	"strconv"
)
/*
accept command line args(numbers) 
      1. convert to number (strconv)
      2. print sum 
	  */
func main(){
	sum := 0
	for i := 1; i< len(os.Args);i++{
		val, err := strconv.Atoi(os.Args[i])
		fmt.Println(val , err)
		if (err != nil){
			fmt.Println("Parameter ", i , " is invalid")
		} else{
			sum += val
		}
	}
	fmt.Println("Sum = " , sum)
}