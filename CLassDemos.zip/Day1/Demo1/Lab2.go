//fmt main
package main
import(
	"fmt"
)
//Write a add function to accept int, int and return sum 
func calc(no1 , no2 int) (int, int){
	return no1+no2, no1-no2
}
func hello(str string) string{
	fmt.Println("Hello Invoked with ...", str)
	return "Hello, "+ str
}
func main(){
	//var i int 
	//i = 1000
    i := 1000
	fmt.Println("Current Value of i = " , i)
	i = 600
	fmt.Println("Current Value of i = " , i)
	fmt.Println(hello("Simple"))
	sum,_ :=  calc(10,30)
	//fmt.Println("Sum of 10,30 is ",sum, " Sub of 10,30 is ", sub)
	fmt.Println("Sum of 10,30 is ",sum)
}
