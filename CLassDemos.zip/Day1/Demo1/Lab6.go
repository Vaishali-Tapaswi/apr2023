package main
import(
	"fmt"
	"os"
	"strconv"
)
func main(){
	str := "abc"
	defer	fmt.Println("Hello " , str)
	val, _ := strconv.Atoi(os.Args[1])
	process(val)
	fmt.Println("World")
	str = "xyz"
}

func process(val int){
	defer fmt.Println("line1")
	fmt.Println("line2")
	sum := 10/val
	fmt.Println("line3= ", sum)
	
}