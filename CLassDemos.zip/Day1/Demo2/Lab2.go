package main
import "fmt"

func main(){
	var emparr [2]Emp
	for i:=0 ;i<len(emparr);i++{
		fmt.Println("Enter Emp Details ")
		emp := Emp{}
		fmt.Scanln(&emp.Empno, &emp.Ename, &emp.Salary)
		emparr[i]= emp
	}
	fmt.Println("\tEmpNo\tEmpName\tSalary")
	/*for i:=0 ;i<len(emparr);i++{
		fmt.Println("\t",emparr[i].Empno ,"\t",emparr[i].Ename,"\t", emparr[i].Salary)
	} */
	for i, v := range emparr{
		fmt.Println(i, "\t",v.Empno ,"\t",v.Ename,"\t", v.Salary)
	}
}