package main
import "fmt"
type Point struct{
	X int
	Y int
}
func main(){
	var line [2]Point

	line[0] = Point{30,60}
	
	line[1] = Point{500,600}
	fmt.Println(line)
}