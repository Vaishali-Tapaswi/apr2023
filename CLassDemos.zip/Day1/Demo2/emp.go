package main 
import "fmt"
type Emp struct{
	Empno int
	Ename string
	Salary int
}
func (emp *Emp) incr11( per int){
	emp.Salary += emp.Salary*per/100
}

func (emp Emp) print(){
	fmt.Println("\t" , emp.Empno ,"\t" , emp.Ename, "\t", emp.Salary)
}
