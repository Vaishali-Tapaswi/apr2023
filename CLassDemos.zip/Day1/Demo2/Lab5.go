package main
import "fmt"
func main(){
	empmgr := EmpMgr{}
	empmgr.print()
	fmt.Println("===============After adding 3 items============")
	empmgr.add(Emp{1,"aaa",111})
	empmgr.add(Emp{2,"bbbb",222})
	empmgr.add(Emp{3,"cccc",3333})
	empmgr.print()
	fmt.Println("===============After adding 3 items============")
	empmgr.add(Emp{4,"aaa",111})
	empmgr.add(Emp{5,"bbbb",222})
//	empmgr.add(Emp{6,"cccc",3333})
empmgr.print()
}