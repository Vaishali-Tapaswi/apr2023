package main 

type EmpMgr struct{
	emparr [5]Emp
	cnt int
}
func (empmgr *EmpMgr) add( emp Emp){
	empmgr.emparr[empmgr.cnt]= emp
	empmgr.cnt++
}

func (empmgr EmpMgr) print(){
	for _,v := range empmgr.emparr {
		v.print()
	}
}
